export default function Historias(){
    return <h1>
        Pagina de Historias
    </h1>
}