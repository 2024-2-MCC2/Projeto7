import React from "react"
import BoxContent from "./ComponentsPaginaDeLogin/BoxContent"
import Titulo from "./ComponentsPaginaDeLogin/Titulo"
export default function Login(){
    return(
       <div>
        <BoxContent/>
        <Titulo/>
        </div>
    )
}