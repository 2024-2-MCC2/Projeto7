import Footer from "../Footer"
export default function Cadastro(){
    return(
        <div>
    <h1>
        Pagina de Cadastro
    </h1>
    <Footer/>
    </div>
    )
}