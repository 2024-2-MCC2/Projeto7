export default function Doacoes(){
    return <h1>
        Pagina de Doacoes
    </h1>
}