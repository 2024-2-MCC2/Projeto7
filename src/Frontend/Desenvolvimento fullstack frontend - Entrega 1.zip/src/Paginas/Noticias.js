export default function Noticias(){
    return <h1>
        Pagina de Cursos
    </h1>
}