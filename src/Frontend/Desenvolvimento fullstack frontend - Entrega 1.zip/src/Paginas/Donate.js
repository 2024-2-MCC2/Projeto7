
export default function Donate(){
    return <h1>
        Pagina de Donate
    </h1>
}